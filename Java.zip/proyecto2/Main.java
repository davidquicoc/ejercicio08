class Main {
    public static void main(String ars[]) {
	// Bucle for para llegar al número 100
        for (float i = 1; i <= 100; i += 0.0000001) {
            System.out.println(i);
        }
    }
}
