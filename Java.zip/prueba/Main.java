class Main {
	public static void main(String args[]) {
		//System.out.println("Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.");
		System.out.println("Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse ullamcorper lacinia tincidunt. Duis sed venenatis justo. Vivamus a lacus justo. Sed feugiat cursus ex. Integer a imperdiet eros, sed malesuada erat. Suspendisse rutrum id erat sed dapibus. Integer nec congue felis. Morbi molestie congue condimentum. Maecenas dapibus, velit a semper aliquet, urna tortor ornare lorem, vitae lobortis urna mauris vitae elit. Nulla pulvinar molestie commodo. Quisque sed lacus mollis, auctor odio facilisis, cursus ante. Aliquam sem augue, tempus ut feugiat nec, euismod eget lectus. Vestibulum et arcu venenatis turpis lobortis venenatis.");
	}
}
