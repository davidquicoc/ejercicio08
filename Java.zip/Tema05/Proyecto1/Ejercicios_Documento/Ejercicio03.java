import java.nio.file.Files;
import java.nio.file.Path;
import java.io.IOException;

class Ejercicio03 {

    public static void main (String[] args) {
        try {
            // Leer el archivo Ejercicio03.txt
            String archivo = Files.readString(Path.of("Ejercicio03.txt"));

            // Cambiar "hola" por "adios"



            // Leer el archivo Ejercicio03.txt
            //String contenidoNuevo = "adios";
            String salida = archivo.replace("hola", "adios");
            Files.writeString (Path.of("Ejercicio03A.txt"), salida);

	    System.out.println(salida);

        } catch (IOException e) {
            System.out.println(e);
        }
    }

}
