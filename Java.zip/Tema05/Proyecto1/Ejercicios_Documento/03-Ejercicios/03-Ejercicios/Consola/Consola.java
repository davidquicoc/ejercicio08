import java.awt.*;
import java.awt.event.*;
import javax.swing.JFrame;
import javax.swing.Timer;
import java.awt.image.BufferedImage;
import javax.swing.JComponent;

// D.Se crea la clase Consola que exitende de JCompent e implementa las interfaces KeyListener y ActionListener
public class Consola extends JComponent implements KeyListener, ActionListener {  

    // D.Se cren los parámetros
    protected int ancho, alto;
    public int tamañoCuadro;
    private Color fondo;
    private Timer timer;
    public JFrame frame;
    private BufferedImage buffer;

    // D.Constructor con parámetros ancho y alto, a los demás atributos se les dará un valor
    Consola(int ancho, int alto) {
        this.ancho = ancho;
        this.alto = alto;
        fondo = Color.LIGHT_GRAY;
        setBackground(fondo);
        tamañoCuadro = 20;
        timer = null;
        setPreferredSize( new Dimension(ancho * tamañoCuadro, alto * tamañoCuadro));
        {
            // Se inicia el buffer gráfico
            buffer = new BufferedImage(ancho * tamañoCuadro, alto * tamañoCuadro, BufferedImage.TYPE_INT_ARGB);
            Graphics g = buffer.getGraphics();
            g.setColor(fondo);
            g.setFont(new Font("Courier", Font.PLAIN, tamañoCuadro));
            Dimension dimensiones = getSize();
            g.fillRect(0, 0, dimensiones.width, dimensiones.height);
        }
        addKeyListener(this);
        frame=new JFrame();  
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(this);  
        frame.pack();
        requestFocus(true);
        //frame.setVisible(true);
        limpiarPantalla();
    }

    /*
     * Método que saca por pantalla la variable 'x' y 'y' 
     */
    public void limpiarPantalla() {
        for(int x=0; x<ancho; x++)
            for(int y=0; y<alto; y++)
                printAt(x, y, ' ');
    }

    /*
     * Método
     */
    public void printAt(int x, int y, char ch) {
        Graphics g = buffer.getGraphics();
        if(ch == '#') {
            g.setColor(Color.black);
            g.fillRect(x*tamañoCuadro, y*tamañoCuadro, tamañoCuadro-1, tamañoCuadro-1);
        } else if(ch == ' ') {
            g.setColor(fondo);
            g.fillRect(x*tamañoCuadro, y*tamañoCuadro, tamañoCuadro-1, tamañoCuadro-1);
        } else {
            g.setColor(Color.black);
            g.drawString(""+ch, x*tamañoCuadro,y*tamañoCuadro+tamañoCuadro);
        }
    }
    
    public void repetirTareaCada(int milisegundos) {
        if(timer == null) {
            timer = new Timer(milisegundos, this);
            timer.start();
        } else {
            timer.stop();
            ActionListener acciones[] = timer.getActionListeners();
            for(int i=0;i<acciones.length;i++)
                timer.removeActionListener(acciones[i]);
            timer.addActionListener(this);
            timer.setDelay(milisegundos);
            timer.start();
        }
        tareaARepetir();
    }
    
    public void pararTarea() {
        timer.stop();
    }
    
    /**
      *
      *
      *
      *
      */
    public void tareaARepetir() {
        System.out.println("Tarea repetida");
    }
    
    // Este método se ejecuta cada vez que se pulsa una tecla
    public void teclaPulsada(KeyEvent e) {
        // Cada tecla tiene asociado un código numérico
        int keyCode = e.getKeyCode();
        String keyString = "key code = " + keyCode
                    + " ("
                    + KeyEvent.getKeyText(keyCode) // Este es el símbolo que corresponde al código
                    + ")";
        System.out.println(keyString);
        
        // Cada tecla tiene un código que se puede consultar en https://docs.oracle.com/javase/7/docs/api/java/awt/event/KeyEvent.html
        // Por ejemplo, se dibuja un cuadro en la posición 0,0 al pulsar espacio:
        
        if(e.getKeyCode() == KeyEvent.VK_SPACE)
            printAt(0,0, '#');
        // Se borra el cuadro de 0,0 al pulsar la tecla izquierda
        else if(e.getKeyCode() == KeyEvent.VK_LEFT)
            printAt(0,0, ' ');
        // Hay que ejecutar repaint para forzar redibujar la pantalla.
        repaint();
    }
    
    public void actionPerformed(ActionEvent evt) {
        tareaARepetir();
    }
   
    public void keyPressed(KeyEvent e) {
        teclaPulsada(e);
    }
    
    public void keyTyped(KeyEvent e) {
    }
 
    public void keyReleased(KeyEvent e) {
    }

    public void paint(Graphics g) {
        g.drawImage(buffer, 0, 0, this);
    }  
    
    public static void main(String[] args) {  
        Consola m=new Consola(20, 30); 
        m.printAt(9,10, '#'); m.printAt(11,10, '#');
        m.printAt(10,9, '#'); m.printAt(10,11, '#');
        m.printAt(10,10,'M');
        m.repetirTareaCada(1000);
        m.frame.setVisible(true);  
    }  
  
}  
