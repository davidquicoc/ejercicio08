/**
 *   Esto es una clase de ejemplo
 */
public class Ejemplo {

    /**Primer valor
     */

    public int a;

    /**Segundo valor
     */

    public int b;

    /**Suma a, b y z.
     * @param z Valor a ser sumado.
     * @return resultado de sumarlos
     */

    public int suma(int z) {
        return suma()+z;
    }

    /**Suma a y b.
     * @return resultado de sumarlos.
     */

    public int suma() {
        return a+b;
    }

    /**Muestra un saludo por la pantalla.
     */

    public void saludo() {
        System.out.println("Hola mundo");
    }

    /**Método público.
     */
    public static void main(String args[]) {
        System.out.println("Hola mundo");
    }

}
