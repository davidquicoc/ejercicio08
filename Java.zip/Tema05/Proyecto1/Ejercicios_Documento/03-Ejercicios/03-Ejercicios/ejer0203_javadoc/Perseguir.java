/*
*    La clase Consola crea una ventana con un tablero. 
*    Con el método printAt(x, y, char) se puede escribir un carácter en la posición x, y.
*    Si el carácter escrito es un '#', se escribe un recuadro de color negro.
*    Si el carácter escrito es un ' ', se borra lo que haya en esa posición.
*    
*    Con limpiarPantalla() se borra el tablero completo.
*    
*    Con repaint() se vuelcan los buffers de dibujo (el dibujo del tablero no va a cambiar
*        hasta que no se haya hecho el repaint()).
*    
*    Las clases hijas deben implementar los métodos:
*        - El constructor de la clase(int ancho, int alto): En el constructor se debe pasar
*            como argumentos el ancho y alto.
*        - tareaARepetir()
*        - teclaPulsada(KeyEvent e)
*    
*    El método repetirTareaCada(milisegundos) ejecuta el método tareaARepetir() cada milisegundos indicados.
*    
*    El método teclaPulsada(KeyEvent e) se ejecuta cada vez que se pulsa una tecla. KeyEvent almacena la tecla
*    que ha sido pulsada. Con e.getKeyCode() se obtiene el código de la tecla que ha sido pulsada. El listado
*    completo de códigos se puede consultar en:
*        https://docs.oracle.com/javase/7/docs/api/java/awt/event/KeyEvent.html
*    
*    A continuación hay un ejemplo de cómo implementar los métodos de la clase Consola.
*/

import java.awt.event.*;

// Clase hija que heredara atributos y métodos de Consola
public class Perseguir extends Consola {

    // Atributos privados de la clase Perseguir
    private int x, y;
    private int enemigo_x, enemigo_y;

    /** Constructor Perseguir con parámetros provenientes de Consola
     * @param ancho
     * @param alto
     */
    Perseguir(int ancho, int alto) {
        super(ancho, alto);
        x = y = 0;
        enemigo_x = ancho-1;
        enemigo_y = alto-1;
        limpiarPantalla();
        printAt(x, y, '#');
        printAt(enemigo_x, enemigo_y, '#');
        repetirTareaCada(100);
    }
    
    /** Se repitre una tarea cada x milisegundos. Usar el método repetirCada para iniciar la tarea.
     */
    public void tareaARepetir() {
        printAt(enemigo_x, enemigo_y, ' ');
        if(x < enemigo_x)
            enemigo_x--;
        else if(x > enemigo_x)
            enemigo_x++;
        if(y < enemigo_y)
            enemigo_y--;
        else if(y > enemigo_y)
            enemigo_y++;
        printAt(enemigo_x, enemigo_y, '#');
        repaint();
    }

    /** Este método se ejecuta cada vez qeu se pulsa una tecla
     * @param e Evento de la tecla que ha sido pulsada
     */
    public void teclaPulsada(KeyEvent e) {
        printAt(x, y, ' ');
         // Se pulsa la tecla izquierda
        if(e.getKeyCode() == KeyEvent.VK_LEFT && x > 0)
            x--;
         // Se pulsa la tecla derecha
        else if(e.getKeyCode() == KeyEvent.VK_RIGHT && x < ancho-1)
            x++;
         // Se pulsa la tecla arriba
        else if(e.getKeyCode() == KeyEvent.VK_UP && y > 0)
            y--;
         // Se pulsa la tecla abajo
        else if(e.getKeyCode() == KeyEvent.VK_DOWN && y < alto-1)
            y++;
        printAt(x, y, '#');
        repaint();
    }
    
    public static void main(String args[]) {
        // Creación de objeto de la clase Perseguir
        Perseguir m=new Perseguir(20, 30);
        m.frame.setVisible(true);  
    }
}
