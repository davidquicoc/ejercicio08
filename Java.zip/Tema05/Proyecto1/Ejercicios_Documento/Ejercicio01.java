import java.nio.file.Files;
import java.nio.file.Path;
import java.io.IOException;

class Ejercicio01 {

    public static void main (String[] args) {
        try {
            String archivo = Files.readString(Path.of("Ejercicio01.txt"));
            System.out.println(archivo);
        } catch (IOException e) {
            System.out.println(e);
        }
    }

}
