import java.nio.file.Files;
import java.nio.file.Path;
import java.io.IOException;

public class Ej08 {
    // throws ICException
    public static void main (String[] args) {
        try {

            // Matriz de clientes usando Strings
            String clientes[] = {"Pepe", "Juan", "Rosa", "Carmen"};

            // Matriz de saldos usando la variable int
            int saldos[] = {100, 123, 34, 47};

            // Lee plantilla.txt
            String plantilla = Files.readString(Path.of("plantilla.fodt"));

            for (int i = 0; i < clientes.length; i++) {
                // Reemplazar los valores del cliente en la plantilla

                //String replace1 = plantilla.replace("$nombre$", clientes[i]);
                String resultado = plantilla.replace("$nombre$", clientes[i]);
                resultado = resultado.replace("$saldo$", "" + saldos[i]);
                // (new Integer(saldos[i])).toString();
                ///String replace2 = replace1.replace("$saldo$", Integer.parseInt(saldos[i]));

                // Generar el nombre del fichero
                String nombre = "cliente-" + i + ".fodt";

                // Guardar el fichero
                Files.writeString (Path.of(nombre), resultado);
            }

        } catch (IOException e) {
            System.out.println(e);
        }
    }
}
