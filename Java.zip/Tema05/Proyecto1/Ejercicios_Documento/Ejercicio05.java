import java.nio.file.Files;
import java.nio.file.Path;
import java.io.IOException;

public class Ejercicio05 {

    public static void main (String[] args) {

        try {
            // Lee el archivo
            String archivo = Files.readString(Path.of("Ejercicio05.java"));
            // Se guardan las líneas del archivo en un array
            String lineas[] = archivo.split("\n");
            // Se recorre el array
            for(int n = 0; n < lineas.length; n++) {
                // Se muestra el número de línea cno la línea
                System.out.println((n + 1) +": " + lineas[n]);
            }
        } catch(IOException e) {
            System.out.println(e);
            // TODO: Falta por implementar
            // FIXME: Se produce un error cuando... Se arregla con
        }
    }
}
