import java.nio.file.Files;
import java.nio.file.Path;
import java.io.IOException;

public class MetodoSplit {

    public static void main (String[] args) {
        String texto = "1,2,tercero,4,5";
        String numeros[] = texto.split(",");

        for (int i = 0; i < numeros.length; i++) {
            System.out.println(numeros[i]);
        }

    }
}
