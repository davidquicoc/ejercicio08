public class MetodoReplace {

    public static void main (String[] args) {

        String mensaje = "Mesquite in your cellar".replace('e', 'o');

        System.out.println(mensaje);

    }

}
