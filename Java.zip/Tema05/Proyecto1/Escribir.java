import java.nio.file.Files;
import java.nio.file.Path;
import java.io.IOException;

class Escribir {

  public static void main (String[] args) {
    try {
      String contenido = "Hola mundo e"; // Crea la línea "Hola Mundo" en el String contenido
      Files.writeString(Path.of("Hola.txt"), contenido); // Crea un fichero llamado "Hola.txt" con el contenido del String
    } catch(IOException e) {
      System.out.println(e);
    }
  }
}
