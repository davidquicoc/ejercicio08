import java.nio.file.Files;
import java.nio.file.Path;
import java.io.IOException;

class pe {
    public static void main (String[] args) {

        try {
            int num = 3;
            buscaNumero(num);
        } catch (IOException e) {
            System.out.println(e);
        }
    }

    static void buscaNumero(int numero) {
        int numeros[] = {17, 26, 28,35, 3};
        String texto;
        for (int i = 0; i < numeros.length; i++) {
            if (numeros[i] == numero) {
                texto = "El número " + numero + " se encuentra en la posición " + i;
                Files.writeString(Path.of(resultado.txt));
            }
        }

    }
}
